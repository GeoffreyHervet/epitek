/*
** o.c for HEADER A LA NORME!!! in /home/hervet_g/
**
** Made by geoffrey hervet
** Login   <hervet_g@epitech.net>
**
** Started on  Sun Mar 25 13:36:49 2012 geoffrey hervet
** Last update Sun Mar 25 13:36:49 2012 geoffrey hervet
*/
/*
** o.c for HEADER A LA NORME!!! in /home/hervet_g/
**
** Made by geoffrey hervet
** Login   <hervet_g@epitech.net>
**
** Started on  Sun Mar 25 13:36:49 2012 geoffrey hervet
** Last update Sun Mar 25 13:36:49 2012 geoffrey hervet
 */
/*
** map_sdl.c for map sdl in /home/poigna_s//tek_2/lemipc-2015-2014s-hervet_g/src/SDL
** 
** Made by sarah poignant
** Login   <poigna_s@epitech.net>
** 
** Started on  Thu Mar 22 16:40:01 2012 sarah poignant
** Last update Thu Mar 22 16:51:40 2012 sarah poignant
*/

#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include	"../../inc/lemipc.h"

#define		KEY_MAP 1

int             *create_map(int key)
{
  int           *map;
  void          *addr;
  int           shm_id;
  int           i;

  shm_id = shmget(key, MAP_SIZE, IPC_CREAT | SHM_R | SHM_W);
  addr = shmat(shm_id, NULL, SHM_R | SHM_W);
  map = (int *)addr;
  for (i = 0; i != MAP_SIZE; i++)
    map[i] = 0;
  return (map);
}

SDL_Surface     *init_sdl(int x, int y)
{
  SDL_Surface   *screen;

  SDL_Init(SDL_INIT_VIDEO);
  screen = SDL_SetVideoMode(x, y, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
  SDL_WM_SetCaption("LEMIPC", NULL);
  SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 255, 255, 255));
  SDL_Flip(screen);
  return (screen);
}

void		map_sdl(int *map, SDL_Surface *square,
			SDL_Surface *screen)
{
  SDL_Rect	position;
  int		j;
  int		length;

  position.x = 30;
  position.y = 30;
  length = 0;
  for (j = 0; j != MAP_SIZE; j++, position.x = position.x + 30)
    {
      if (map[j] == 0)
        SDL_BlitSurface(square, NULL, screen, &position);
      if (length >= MAP_WIDTH)
        {
          length = 0;
          position.y = position.y + 30;
          position.x = 0;
        }
    }
  SDL_Flip(screen);
}

void           Rect(SDL_Surface *i, int position_x, int position_y)
{
  SDL_Rect      Rect;

  Rect.x = position_x;
  Rect.y = position_y;
  Rect.w = 30;
  Rect.h = 30;
}

void            aff_map(int *map)
{
  int           i;
  int           len;

  len = 0;
  for (i = 0; i != MAP_SIZE; i++)
    {
      printf("%i ", map[i]);
      len++;
      if (len >= MAP_WIDTH)
        {
          printf("\n");
          len = 0;
        }
    }
  printf("\n");
}

key_t           get_key(const char *path, int id) /*  ftok  -  convert  a pathname and a project identifier to a System V IPC
						      key */
{
  key_t         k;

  if (path == NULL)
    perror(":pathname");
  k = ftok(path, id);
  return (k);
}

int             *get_map(const char *pathname, int id)
{
  key_t         key;
  int           id_shm;
  void          *address;

  key = get_key(getenv("HOME"), KEY_MAP);
  id_shm = shmget(key, MAP_SIZE, SHM_R | SHM_W); /* READ ET WRITE FOR USER */ 
  printf("Shm : %i\n", id_shm);
  if (id_shm == -1) /* RETURN VALUE */
    return (create_map(key));
  address = shmat(id_shm, NULL, SHM_R | SHM_W); /* La fonction shmat() attache le segment de mémoire partagée identifié par shmid au segment de données du processus appelant. */
  return ((int *)address);
}

int             main(const char *pathname, int id)
{
  SDL_Surface	*square;
  SDL_Surface   *screen; 
  SDL_Event     event;
  int           *map;
  
  map = get_map(pathname, id);
   screen = init_sdl((MAP_WIDTH * 30) + 60, (MAP_WIDTH * 30) + 60);
   if (screen == NULL)
    perror("Error : Cannot load sdl\n");
   while (1)
     {
       while (SDL_PollEvent(&event)) /* Polls for currently pending events.

If event is not NULL, the next event is removed from the queue and stored in the SDL_Event structure pointed to by event. */
       map_sdl(map, square, screen);
       usleep(800);
     }
   return (EXIT_SUCCESS);
}

